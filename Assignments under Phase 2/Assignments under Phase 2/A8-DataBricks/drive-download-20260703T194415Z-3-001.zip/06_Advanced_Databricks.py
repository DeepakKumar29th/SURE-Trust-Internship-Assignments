# Databricks notebook source
# MAGIC %md
# MAGIC # Advanced Databricks Concepts
# MAGIC
# MAGIC ## Objective
# MAGIC
# MAGIC This notebook demonstrates advanced Databricks features used in production environments.
# MAGIC
# MAGIC The concepts include:
# MAGIC
# MAGIC - Delta Tables
# MAGIC - MERGE (Upsert)
# MAGIC - Schema Evolution
# MAGIC - Time Travel
# MAGIC - Incremental Processing
# MAGIC - Performance Optimization
# MAGIC - Workflow Design

# COMMAND ----------

# MAGIC %md
# MAGIC ## PART 1: Delta Tables
# MAGIC
# MAGIC The Bronze, Silver, and Gold layers have been stored as Delta Tables instead of CSV files.
# MAGIC
# MAGIC Benefits of Delta Tables:
# MAGIC
# MAGIC - ACID Transactions
# MAGIC - Faster Query Performance
# MAGIC - Version History
# MAGIC - Time Travel
# MAGIC - MERGE Support
# MAGIC - Schema Evolution

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Displays all Bronze Delta Tables.
# MAGIC
# MAGIC SHOW TABLES IN bronze;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Displays all Silver Delta Tables.
# MAGIC
# MAGIC SHOW TABLES IN silver;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Displays all Gold Delta Tables.
# MAGIC
# MAGIC SHOW TABLES IN gold;

# COMMAND ----------

# MAGIC %md
# MAGIC ## PART 2: MERGE (Upsert)
# MAGIC
# MAGIC ###Business Scenario
# MAGIC In real businesses, records may change after they are loaded.
# MAGIC
# MAGIC Instead of reloading the complete dataset, MERGE updates only the changed records.

# COMMAND ----------

# Create a small correction dataset.
# Creates a small dataset to simulate late-arriving order updates.

from pyspark.sql import Row

updates = spark.createDataFrame([

    Row(
        order_id="e481f51cbdc54678b7cc49136f2d6af7",
        order_status="canceled"
    ),

    Row(
        order_id="53cdb2fc8bc7dce0b6741e2150273451",
        order_status="canceled"
    )

])

display(
    updates.select(
        "order_id",
        "order_status"
    )
)

# COMMAND ----------

# Create a temporary view.
# Creates a temporary SQL view for the update dataset.

updates.createOrReplaceTempView("updates")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Updates existing records without rebuilding the entire table.
# MAGIC
# MAGIC MERGE INTO silver.marketplace AS target
# MAGIC
# MAGIC USING updates AS source
# MAGIC
# MAGIC ON target.order_id = source.order_id
# MAGIC
# MAGIC WHEN MATCHED THEN
# MAGIC
# MAGIC UPDATE SET
# MAGIC
# MAGIC target.order_status = source.order_status;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- verify
# MAGIC --Verifies that the updated records were successfully merged.
# MAGIC
# MAGIC SELECT
# MAGIC
# MAGIC order_id,
# MAGIC
# MAGIC order_status
# MAGIC
# MAGIC FROM silver.marketplace
# MAGIC
# MAGIC WHERE order_id IN (
# MAGIC
# MAGIC 'e481f51cbdc54678b7cc49136f2d6af7',
# MAGIC
# MAGIC '53cdb2fc8bc7dce0b6741e2150273451'
# MAGIC
# MAGIC );

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part 3: Time Travel
# MAGIC
# MAGIC Delta Tables keep previous versions of data.
# MAGIC
# MAGIC This allows us to view or recover earlier versions of a table.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Displays the complete version history of the Delta Table.
# MAGIC
# MAGIC DESCRIBE HISTORY silver.marketplace;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query an earlier version.
# MAGIC -- Reads data from an earlier version using Time Travel.
# MAGIC
# MAGIC SELECT *
# MAGIC
# MAGIC FROM silver.marketplace
# MAGIC
# MAGIC VERSION AS OF 0
# MAGIC
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part 4: Schema Evolution
# MAGIC
# MAGIC Sometimes new columns appear in future data files.
# MAGIC
# MAGIC Delta Tables can automatically handle these schema changes.

# COMMAND ----------

# Simulates a new data file containing an additional column.

from pyspark.sql.functions import lit

new_orders = (

spark.table("bronze.orders")

.withColumn(

"delivery_partner",

lit("BlueDart")

)

)

display(new_orders.limit(5))

# COMMAND ----------

# Saves the dataset using automatic schema evolution.

(
new_orders.write
.option("mergeSchema","true")
.mode("overwrite")
.format("delta")
.saveAsTable("bronze.orders_schema_demo")
)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verifies that the new column was added successfully.
# MAGIC
# MAGIC DESCRIBE bronze.orders_schema_demo;

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

