# Databricks notebook source
# MAGIC %md
# MAGIC # Silver Layer
# MAGIC
# MAGIC ## Objective
# MAGIC
# MAGIC The Silver Layer cleans, validates, and integrates raw Bronze tables.
# MAGIC
# MAGIC Activities performed:
# MAGIC
# MAGIC - Remove duplicates
# MAGIC - Handle missing values
# MAGIC - Validate business rules
# MAGIC - Standardize data
# MAGIC - Join multiple datasets
# MAGIC - Create business-ready tables
# MAGIC

# COMMAND ----------

# Import Libraries
from pyspark.sql.functions import *

# COMMAND ----------

# Load Bronze Tables
# In this step, we load all Bronze Delta tables into Spark DataFrames.
# These tables contain the raw data created in the Bronze Layer and will now be cleaned and validated.

orders = spark.table("bronze.orders")
customers = spark.table("bronze.customers")
items = spark.table("bronze.order_items")
payments = spark.table("bronze.order_payments")
reviews = spark.table("bronze.order_reviews")
products = spark.table("bronze.products")
sellers = spark.table("bronze.sellers")
categories = spark.table("bronze.category_translation")

# COMMAND ----------

display(orders.limit(5))

# COMMAND ----------

# Check Record Counts
# We verify the number of records in each Bronze table to ensure that all datasets have been loaded successfully before any transformation is performed.

print("Orders:", orders.count())
print("Customers:", customers.count())
print("Items:", items.count())
print("Payments:", payments.count())
print("Reviews:", reviews.count())
print("Products:", products.count())
print("Sellers:", sellers.count())
print("Categories:", categories.count())

# COMMAND ----------

# Check Duplicate Records
# Before removing duplicate records, we first check whether duplicates exist.
# This helps us understand the quality of the incoming data.

print("Duplicate Orders:", orders.count() - orders.dropDuplicates().count())
print("Duplicate Customers:", customers.count() - customers.dropDuplicates().count())
print("Duplicate Items:", items.count() - items.dropDuplicates().count())
print("Duplicate Payments:", payments.count() - payments.dropDuplicates().count())
print("Duplicate Reviews:", reviews.count() - reviews.dropDuplicates().count())
print("Duplicate Products:", products.count() - products.dropDuplicates().count())
print("Duplicate Sellers:", sellers.count() - sellers.dropDuplicates().count())
print("Duplicate Categories:", categories.count() - categories.dropDuplicates().count())

# COMMAND ----------

# Duplicate records have been removed

orders = orders.dropDuplicates(["order_id"])
customers = customers.dropDuplicates(["customer_id"])
items = items.dropDuplicates(["order_id", "order_item_id"])
payments = payments.dropDuplicates(["order_id", "payment_sequential"])
reviews = reviews.dropDuplicates(["review_id"])
products = products.dropDuplicates(["product_id"])
sellers = sellers.dropDuplicates(["seller_id"])
categories = categories.dropDuplicates(["product_category_name"])

# COMMAND ----------

# Check Null Values
# This table shows the number of missing values in every column.
# It helps identify which columns require validation or cleaning.

display(
    orders.select([
        count(when(col(c).isNull(), c)).alias(c)
        for c in orders.columns
    ])
)

# COMMAND ----------

# Business Validation-create a clean orders table
# Remove records with missing Order ID or Customer ID to keep only valid orders.

orders_clean = (
    orders
    .filter(col("order_id").isNotNull())
    .filter(col("customer_id").isNotNull())
)

display(orders_clean.select("order_id","customer_id","order_status").limit(10))

# COMMAND ----------

# Remove Metadata Columns
# Remove Bronze metadata columns because they are no longer required.

orders_clean = orders_clean.drop(
    "ingestion_timestamp",
    "source_file"
)

# COMMAND ----------

# Delivery Days - Create a new column
# Calculate the number of days taken to deliver each order.

orders_clean = (
    orders_clean
    .withColumn(
        "delivery_days",
        datediff(
            col("order_delivered_customer_date"),
            col("order_purchase_timestamp")
        )
    )
)

display(
    orders_clean.select(
        "order_purchase_timestamp",
        "order_delivered_customer_date",
        "delivery_days"
    ).limit(10)
)

# COMMAND ----------

# Late Delivery Flag
# Identify whether an order was delivered late.

orders_clean = (
    orders_clean
    .withColumn(
        "late_delivery",
        when(
            col("order_delivered_customer_date") >
            col("order_estimated_delivery_date"),
            "Yes"
        ).otherwise("No")
    )
)

display(orders_clean.select("order_id","late_delivery").limit(10))

# COMMAND ----------

# Payment Summary - One order can have multiple payments
# Combine multiple payments into one summary for each order.

payments_summary = (
    payments
    .groupBy("order_id")
    .agg(
        sum("payment_value").alias("total_payment"),
        first("payment_type").alias("payment_type")
    )
)

display(payments_summary.limit(10)) # Verify the payment summary.

# COMMAND ----------

# Category Translation - Join products with English category names

products_clean = (
    products
    .join(
        categories,
        "product_category_name",
        "left"
    )
)

# Verify that category names are translated correctly.
display(
    products_clean.select(
        "product_id",
        "product_category_name",
        "product_category_name_english"
    ).limit(10)
)

# COMMAND ----------

# Remove unnecessary metadata columns.

products_clean = products_clean.drop(
    "ingestion_timestamp",
    "source_file"
)

# COMMAND ----------

# Remove metadata from all tables before joining.

customers = customers.drop("ingestion_timestamp", "source_file")
items = items.drop("ingestion_timestamp", "source_file")
payments = payments.drop("ingestion_timestamp", "source_file")
reviews = reviews.drop("ingestion_timestamp", "source_file")
products = products.drop("ingestion_timestamp", "source_file")
sellers = sellers.drop("ingestion_timestamp", "source_file")
categories = categories.drop("ingestion_timestamp", "source_file")

# COMMAND ----------

# Create the Marketplace Table

# In this step, all cleaned datasets are joined together to create one business-ready marketplace dataset.
# This table will be used for reporting in the Gold Layer.

marketplace = (
    orders_clean
    .join(customers, "customer_id", "left")
    .join(items, "order_id", "left")
    .join(payments_summary, "order_id", "left")
    .join(reviews, "order_id", "left")
    .join(products_clean, "product_id", "left")
    .join(sellers, "seller_id", "left")
)

# COMMAND ----------

# Preview the final joined dataset
display(
    marketplace.select(
        "order_id",
        "customer_unique_id",
        "seller_id",
        "payment_type",
        "price"
    ).limit(10)
)

# COMMAND ----------

# Display the structure and data types of the marketplace table
marketplace.printSchema()

# COMMAND ----------

# Create the Silver schema if it does not already exist.

spark.sql("""
CREATE SCHEMA IF NOT EXISTS silver
""")

# COMMAND ----------

# Create Revenue
# Calculate total revenue for each order.

marketplace = (
    marketplace
    .withColumn(
        "revenue",
        col("price") + col("freight_value")
    )
)

display(
    marketplace.select(
        "price",
        "freight_value",
        "revenue"
    ).limit(10)
)

# COMMAND ----------

# Create Review Category
# Convert review scores into business-friendly categories

marketplace = (
    marketplace
    .withColumn(
        "review_category",
        when(col("review_score") >= 4, "Good")
        .when(col("review_score") == 3, "Average")
        .otherwise("Poor")
    )
)

display(
    marketplace.select(
        "review_score",
        "review_category"
    ).limit(10)
)

# COMMAND ----------

# Create Quarantine Table - Instead of deleting bad data, store it separately

# Invalid records are not deleted.
# Instead, they are stored separately for auditing and future correction.

quarantine = marketplace.filter(
    col("order_id").isNull()
    |
    col("seller_id").isNull()
    |
    (col("price") < 0)
    |
    (col("freight_value") < 0)
    |
    (
        col("order_delivered_customer_date")
        <
        col("order_purchase_timestamp")
    )
)

# COMMAND ----------

# Valid Records
# Keep only valid records for the Silver layer.

silver_marketplace = marketplace.filter(
    (col("order_id").isNotNull()) &
    (col("seller_id").isNotNull()) &
    (col("price") >= 0) &
    (col("freight_value") >= 0)
)

# COMMAND ----------

# Keep only valid records for the Silver layer

print("Valid Records:", silver_marketplace.count())
print("Quarantine Records:", quarantine.count())

display(quarantine.limit(10))

# COMMAND ----------

## Save Silver Tables

(
    silver_marketplace.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("silver.marketplace")
)

# COMMAND ----------

# Save Quarantine
# Save the rejected records for future auditing.

(
    quarantine.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("silver.quarantine")
)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify
# MAGIC --Verify that the Silver table was created successfully.
# MAGIC
# MAGIC SELECT *
# MAGIC FROM silver.marketplace
# MAGIC LIMIT 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- View the version history of the Silver Delta Table
# MAGIC
# MAGIC DESCRIBE HISTORY silver.marketplace;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Check Quarantine
# MAGIC -- Verify that invalid records are stored in the quarantine table
# MAGIC
# MAGIC SELECT *
# MAGIC FROM silver.quarantine;

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Silver Layer Summary
# MAGIC ### Data Cleaning Performed
# MAGIC
# MAGIC - Removed duplicate records.
# MAGIC - Removed invalid primary keys.
# MAGIC - Calculated delivery days.
# MAGIC - Created late delivery flag.
# MAGIC - Calculated revenue.
# MAGIC - Standardized product categories.
# MAGIC - Joined multiple business tables.
# MAGIC - Created review categories.
# MAGIC - Separated invalid records into a quarantine table.
# MAGIC - Stored cleaned data in Delta format.

# COMMAND ----------

