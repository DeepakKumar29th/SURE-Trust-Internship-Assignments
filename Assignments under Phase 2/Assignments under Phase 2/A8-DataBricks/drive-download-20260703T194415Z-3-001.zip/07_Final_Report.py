# Databricks notebook source
# MAGIC %md
# MAGIC # Marketplace Lakehouse Pipeline, Revenue Audit, and Seller Performance Intelligence
# MAGIC
# MAGIC ## Business Problem
# MAGIC
# MAGIC The company receives raw CSV files from multiple operational systems such as orders, payments, sellers, customers, products, and reviews.
# MAGIC
# MAGIC Using raw CSV files directly for reporting can lead to inconsistent dashboards, duplicate records, missing values, and poor data quality.
# MAGIC
# MAGIC The objective of this project is to build a Databricks Lakehouse Pipeline using the Bronze–Silver–Gold architecture to create reliable, business-ready reporting tables.

# COMMAND ----------

# MAGIC %md
# MAGIC # Dataset Used
# MAGIC
# MAGIC Brazilian E-Commerce Public Dataset by Olist
# MAGIC
# MAGIC Files Used
# MAGIC
# MAGIC - Orders
# MAGIC - Order Items
# MAGIC - Payments
# MAGIC - Reviews
# MAGIC - Customers
# MAGIC - Sellers
# MAGIC - Products
# MAGIC - Category Translation
# MAGIC - Geolocation (Optional)
# MAGIC
# MAGIC These datasets represent different business systems that were integrated into a unified marketplace reporting layer.

# COMMAND ----------

# MAGIC %md
# MAGIC # Lakehouse Architecture
# MAGIC
# MAGIC Raw CSV Files
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC Bronze Layer
# MAGIC (Raw Delta Tables)
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC Silver Layer
# MAGIC (Cleaned, Validated and Joined Data)
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC Gold Layer
# MAGIC (Business Summary Tables)
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC SQL Analysis
# MAGIC
# MAGIC ↓
# MAGIC
# MAGIC Executive Dashboard

# COMMAND ----------

# MAGIC %md
# MAGIC # Bronze Layer
# MAGIC
# MAGIC Completed Tasks
# MAGIC
# MAGIC - Loaded raw CSV files.
# MAGIC - Stored data as Delta Tables.
# MAGIC - Added ingestion metadata.
# MAGIC - Preserved original data without modifications.
# MAGIC
# MAGIC Purpose
# MAGIC
# MAGIC The Bronze Layer serves as the source of truth and supports auditing and future reprocessing.

# COMMAND ----------

# MAGIC %md
# MAGIC # Silver Layer
# MAGIC
# MAGIC Completed Tasks
# MAGIC
# MAGIC - Removed duplicate records.
# MAGIC - Validated primary keys.
# MAGIC - Handled missing values.
# MAGIC - Created delivery metrics.
# MAGIC - Created review categories.
# MAGIC - Calculated revenue.
# MAGIC - Joined multiple datasets.
# MAGIC - Created quarantine table.

# COMMAND ----------

# MAGIC %md
# MAGIC # Gold Layer
# MAGIC
# MAGIC Business Summary Tables Created
# MAGIC
# MAGIC - Executive KPI
# MAGIC - Seller Performance
# MAGIC - Category Revenue
# MAGIC - Customer State Revenue
# MAGIC - Payment Summary
# MAGIC - Delivery Summary
# MAGIC - Review Summary
# MAGIC
# MAGIC These tables are optimized for dashboards and business reporting.

# COMMAND ----------

# MAGIC %md
# MAGIC # Advanced Databricks Concepts Used
# MAGIC
# MAGIC Implemented
# MAGIC
# MAGIC - Delta Tables
# MAGIC - MERGE (Upsert)
# MAGIC - Schema Evolution
# MAGIC - Time Travel
# MAGIC - Quarantine Layer
# MAGIC - Delta History
# MAGIC - SQL Reporting
# MAGIC
# MAGIC Explored
# MAGIC
# MAGIC - Performance Optimization
# MAGIC - Workflow Design
# MAGIC - Unity Catalog
# MAGIC - Incremental Processing

# COMMAND ----------

# MAGIC %md
# MAGIC # Business Insights
# MAGIC
# MAGIC 1. Revenue is concentrated among a relatively small number of sellers.
# MAGIC
# MAGIC 2. Credit Card is the most frequently used payment method.
# MAGIC
# MAGIC 3. Sellers with late deliveries generally receive lower review scores.
# MAGIC
# MAGIC 4. Some product categories generate significantly higher revenue than others.
# MAGIC
# MAGIC 5. Customer purchases are concentrated in a few states.
# MAGIC
# MAGIC 6. The quarantine layer successfully isolates invalid records instead of deleting them.
# MAGIC
# MAGIC 7. Delta Tables provide a reliable and auditable storage layer for business reporting.

# COMMAND ----------

# MAGIC %md
# MAGIC # Final Recommendation
# MAGIC
# MAGIC The company should NOT build dashboards directly from raw CSV files.
# MAGIC
# MAGIC Instead, dashboards should use the Gold Layer because it contains clean, validated, and business-ready data.
# MAGIC
# MAGIC Benefits
# MAGIC
# MAGIC - Better Data Quality
# MAGIC - Reliable KPIs
# MAGIC - Faster Reporting
# MAGIC - Easier Auditing
# MAGIC - Version Control
# MAGIC - Better Performance
# MAGIC - Easier Maintenance
# MAGIC
# MAGIC The Bronze–Silver–Gold Lakehouse architecture provides a scalable solution for future business growth.

# COMMAND ----------

# MAGIC %md
# MAGIC # What I Learned Beyond Class
# MAGIC
# MAGIC 1. Delta Lake supports ACID transactions and version history.
# MAGIC
# MAGIC 2. MERGE allows updating existing records without rebuilding entire tables.
# MAGIC
# MAGIC 3. Schema Evolution enables pipelines to handle new columns.
# MAGIC
# MAGIC 4. Time Travel allows recovering previous versions of Delta Tables.
# MAGIC
# MAGIC 5. Databricks Medallion Architecture separates raw, cleaned, and business-ready data.

# COMMAND ----------

# MAGIC %md
# MAGIC # Interview Questions
# MAGIC
# MAGIC ## Why did you separate Bronze, Silver, and Gold?
# MAGIC
# MAGIC Bronze stores raw data, Silver cleans and validates it, and Gold provides business-ready summary tables.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why not build dashboards directly from CSV files?
# MAGIC
# MAGIC Raw CSV files may contain duplicates, missing values, inconsistent formats, and invalid records, leading to inaccurate dashboards.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why use Delta Tables?
# MAGIC
# MAGIC Delta Tables provide ACID transactions, version history, MERGE support, schema evolution, and better reliability than CSV files.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Why create a quarantine table?
# MAGIC
# MAGIC To isolate invalid records for auditing instead of deleting them, preserving data integrity.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## How did you identify seller performance?
# MAGIC
# MAGIC Using revenue, delivery performance, review scores, and order counts from the Gold Seller Summary table.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## How did you connect delivery delay with review score?
# MAGIC
# MAGIC By calculating delivery days, creating a late delivery flag, and comparing it with customer review scores.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## How would you handle late-arriving updates?
# MAGIC
# MAGIC Using Delta MERGE to update only changed records instead of rebuilding the entire table.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## How would you handle new columns?
# MAGIC
# MAGIC Using Delta Schema Evolution with `mergeSchema`.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## How would you schedule this pipeline?
# MAGIC
# MAGIC Using Databricks Workflows with sequential tasks for Bronze, Silver, Gold, validation, and reporting.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## What makes this a Databricks project?
# MAGIC
# MAGIC It uses Delta Tables, Medallion Architecture, MERGE, Time Travel, Quarantine Layer, SQL Analytics, and Databricks Lakehouse principles instead of only Python or Pandas.

# COMMAND ----------

