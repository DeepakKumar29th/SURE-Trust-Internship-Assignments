# Databricks notebook source
# MAGIC %md
# MAGIC # Bronze Layer
# MAGIC
# MAGIC ## Objective
# MAGIC
# MAGIC The Bronze Layer stores raw CSV files exactly as received from the source systems.
# MAGIC
# MAGIC No business transformations are performed here.
# MAGIC
# MAGIC This layer acts as the source of truth for all downstream processing.
# MAGIC
# MAGIC The raw data is stored as Delta Tables to support auditing, versioning, and reliable data processing.

# COMMAND ----------

# Imports the PySpark functions required for metadata and data processing.

from pyspark.sql.functions import current_timestamp, col, lit

# COMMAND ----------

# Base folder where all CSV files are stored

base_path = "/Volumes/workspace/default/marketplace/raw/"

# COMMAND ----------

# Reads the Orders CSV file into a Spark DataFrame.

orders_df = (
    spark.read
         .option("header", "true")
         .option("inferSchema", "true")
         .csv(base_path + "olist_orders_dataset.csv")
)

display(
    orders_df.select(
        "order_id",
        "customer_id",
        "order_status"
    ).limit(10)
)

# COMMAND ----------

# Displays sample records to verify that the data was loaded correctly.

display(orders_df)

# COMMAND ----------

# Shows the dataset structure and data types.
# # Displays the total number of records in the Orders dataset.

print("Total Orders:", orders_df.count())
print("Total Columns:", len(orders_df.columns))

# COMMAND ----------

# Add Bronze Metadata
#Adds metadata such as ingestion time and source file to the dataset.

from pyspark.sql.functions import current_timestamp, lit

orders_bronze = (
    orders_df
        .withColumn("ingestion_timestamp", current_timestamp())
        .withColumn(
            "source_file",
            lit(base_path + "olist_orders_dataset.csv")
        )
)

# COMMAND ----------

# Preview Bronze Table

display(
    orders_bronze.select(
        "order_id",
        "ingestion_timestamp",
        "source_file"
    ).limit(10)
)

# COMMAND ----------

# Save as Delta Table
# Saves the Orders dataset as a Bronze Delta Table.

(
    orders_bronze.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("bronze.orders")
)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the Table
# MAGIC -- Verifies that the Bronze Orders table was created successfully.
# MAGIC
# MAGIC SELECT
# MAGIC order_id,
# MAGIC customer_id,
# MAGIC order_status,
# MAGIC ingestion_timestamp
# MAGIC FROM bronze.orders
# MAGIC LIMIT 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Check Table Type
# MAGIC -- Displays detailed information about the Bronze Orders table.
# MAGIC
# MAGIC DESCRIBE EXTENDED bronze.orders;

# COMMAND ----------

# Create a Reusable Function
# # Reusable function to load any CSV file into the Bronze Layer

from pyspark.sql.functions import current_timestamp, lit

def load_to_bronze(file_name, table_name):
    
    # Read CSV file
    df = (
        spark.read
             .option("header", "true")
             .option("inferSchema", "true")
             .csv(base_path + file_name)
    )

    # Add metadata
    bronze_df = (
        df
        .withColumn("ingestion_timestamp", current_timestamp())
        .withColumn("source_file", lit(base_path + file_name))
    )

    # Save as Delta Table
    (
        bronze_df.write
        .format("delta")
        .mode("overwrite")
        .saveAsTable(f"bronze.{table_name}")
    )

    print(f" ✅ Bronze table created : bronze.{table_name}")

# COMMAND ----------

# Load All Datasets
# Loads all remaining datasets into Bronze Delta Tables.

load_to_bronze("olist_customers_dataset.csv", "customers")
load_to_bronze("olist_order_items_dataset.csv", "order_items")
load_to_bronze("olist_order_payments_dataset.csv", "order_payments")
load_to_bronze("olist_order_reviews_dataset.csv", "order_reviews")
load_to_bronze("olist_orders_dataset.csv", "orders")
load_to_bronze("olist_products_dataset.csv", "products")
load_to_bronze("olist_sellers_dataset.csv", "sellers")
load_to_bronze("product_category_name_translation.csv","category_translation")
load_to_bronze("olist_geolocation_dataset.csv","geolocation")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify Bronze Tables
# MAGIC -- Displays all Bronze tables created in the project.
# MAGIC
# MAGIC SHOW TABLES IN bronze;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify One More Table
# MAGIC -- Verifies that the Bronze Products table was created successfully.
# MAGIC
# MAGIC SELECT * FROM bronze.products LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Check Table History
# MAGIC -- Displays the version history of the Bronze Delta Table for auditing and tracking changes.
# MAGIC
# MAGIC DESCRIBE HISTORY bronze.orders;

# COMMAND ----------

# MAGIC %md
# MAGIC # Bronze Layer Summary
# MAGIC
# MAGIC Completed Successfully:
# MAGIC
# MAGIC - Loaded raw CSV files
# MAGIC - Added metadata
# MAGIC - Created Bronze Delta Tables
# MAGIC - Preserved original data
# MAGIC - Verified tables
# MAGIC - Verified Delta history
# MAGIC
# MAGIC The Bronze Layer is now ready for the Silver Layer, where the data will be cleaned and validated.

# COMMAND ----------

