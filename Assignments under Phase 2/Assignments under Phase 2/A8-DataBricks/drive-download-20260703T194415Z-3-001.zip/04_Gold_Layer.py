# Databricks notebook source
# MAGIC %md
# MAGIC # Gold Layer
# MAGIC
# MAGIC ## Objective
# MAGIC
# MAGIC The Gold Layer contains business-ready summary tables created from the Silver Layer.
# MAGIC
# MAGIC These tables are optimized for dashboards and executive reporting.

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

# # Load Silver Table
# Load the cleaned marketplace table created in the Silver Layer.
# This table will be used to generate business reports.

marketplace = spark.table("silver.marketplace")
print("Marketplace Records:", marketplace.count())
print("Marketplace Columns:", len(marketplace.columns))
print(marketplace.columns)

# COMMAND ----------

# Display the dataset structure and data types.

marketplace.printSchema()

# COMMAND ----------

# Preview records before creating business reports.
display(marketplace.limit(10))

# COMMAND ----------

# Create Gold Schema
# Create the Gold schema to store business summary tables.

spark.sql("""
CREATE SCHEMA IF NOT EXISTS gold
""")

# COMMAND ----------

# GOLD TABLE 1
# Executive KPI Table
# This table provides overall marketplace performance and is mainly used by senior management dashboards.
# Calculate overall business KPIs such as orders, revenue, reviews, and delivery performance.

executive_kpi = marketplace.agg(

    countDistinct("order_id").alias("total_orders"),

    sum(
        when(col("order_status")=="delivered",1)
        .otherwise(0)
    ).alias("delivered_orders"),

    sum(
        when(col("order_status").isin("canceled","unavailable"),1)
        .otherwise(0)
    ).alias("cancelled_orders"),

    round(sum("revenue"),2).alias("total_revenue"),

    round(avg("revenue"),2).alias("average_order_value"),

    round(avg("review_score"),2).alias("average_review_score"),

    round(avg("delivery_days"),2).alias("average_delivery_days")
)

display(executive_kpi)

# COMMAND ----------

# Save the Executive KPI table as a Gold Delta Table

(
    executive_kpi.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("gold.executive_kpi")
)

# COMMAND ----------

# GOLD TABLE 2
# Seller Performance
# This table measures revenue, order volume, delivery performance, and customer satisfaction for each seller.

seller_summary = (
    marketplace
    .groupBy("seller_id")

    .agg(

        round(sum("revenue"),2).alias("seller_revenue"),

        countDistinct("order_id").alias("orders"),

        round(avg("review_score"),2).alias("average_review"),

        round(avg("delivery_days"),2).alias("average_delivery_days"),

        round(

            avg(

                when(col("late_delivery")=="Yes",1)
                .otherwise(0)

            )*100,2

        ).alias("late_delivery_percent")

    )
)

display(
    seller_summary.select(
        "seller_id",
        "seller_revenue",
        "orders",
        "average_review",
        "late_delivery_percent"
    )
    .orderBy(desc("seller_revenue"))
    .limit(10)
)

# COMMAND ----------

# Save the Seller Performance table in the Gold Layer

(
seller_summary.write
.format("delta")
.mode("overwrite")
.saveAsTable("gold.seller_summary")
)

# COMMAND ----------

# GOLD TABLE 3
# Category Revenue
# # Shows revenue and customer reviews for each product category.

category_summary = (

marketplace

.groupBy("product_category_name_english")

.agg(

round(sum("revenue"),2).alias("category_revenue"),

countDistinct("order_id").alias("orders"),

round(avg("review_score"),2).alias("average_review")

)

.orderBy(desc("category_revenue"))

)

display(
    category_summary.select(
        "product_category_name_english",
        "category_revenue",
        "orders",
        "average_review"
    ).limit(10)
)

# COMMAND ----------

# Save the Category Revenue table in the Gold Layer

(
category_summary.write
.format("delta")
.mode("overwrite")
.saveAsTable("gold.category_summary")
)

# COMMAND ----------

# GOLD TABLE 4
# Customer State Revenue
# # Calculates revenue generated from each customer state.

state_summary = (

marketplace

.groupBy("customer_state")

.agg(

round(sum("revenue"),2).alias("state_revenue"),

countDistinct("order_id").alias("orders")

)

.orderBy(desc("state_revenue"))

)

display(
    state_summary.select(
        "customer_state",
        "state_revenue",
        "orders"
    ).limit(10)
)

# COMMAND ----------

# Save the Customer State Revenue table

(
    state_summary.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("gold.state_summary")
)

# COMMAND ----------

# GOLD TABLE 5
# Payment Summary
# Summarizes orders and revenue by payment method.

payment_summary = (

marketplace

.groupBy("payment_type")

.agg(

countDistinct("order_id").alias("orders"),

round(sum("revenue"),2).alias("revenue")

)

)

display(
    payment_summary.select(
        "payment_type",
        "orders",
        "revenue"
    )
)

# COMMAND ----------

# Save the Payment Summary table
(
    payment_summary.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("gold.payment_summary")
)

# COMMAND ----------

# GOLD TABLE 6
# Delivery Summary
# Compares delivery performance with customer reviews.

delivery_summary = (

marketplace

.groupBy("late_delivery")

.agg(

count("*").alias("orders"),

round(avg("review_score"),2).alias("average_review"),

round(avg("delivery_days"),2).alias("average_delivery")

)

)

display(
    delivery_summary.select(
        "late_delivery",
        "orders",
        "average_review",
        "average_delivery"
    )
)

# COMMAND ----------

# Save the Delivery Summary table
(
    delivery_summary.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("gold.delivery_summary")
)

# COMMAND ----------

# GOLD TABLE 7
# Review Summary
# Groups customer reviews into business-friendly categories.

review_summary = (

marketplace

.groupBy("review_category")

.agg(

count("*").alias("orders"),

round(avg("revenue"),2).alias("average_revenue")

)

)

display(
    review_summary.select(
        "review_category",
        "orders",
        "average_revenue"
    )
)

# COMMAND ----------

# Save the Review Summary table.
(
    review_summary.write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("gold.review_summary")
)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify that all Gold tables have been created successfully.
# MAGIC
# MAGIC SHOW TABLES IN gold;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- View the Executive KPI table.
# MAGIC
# MAGIC SELECT * FROM gold.executive_kpi;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the Seller Performance table.
# MAGIC
# MAGIC SELECT * FROM gold.seller_summary LIMIT 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the Category Revenue table.
# MAGIC
# MAGIC SELECT * FROM gold.category_summary LIMIT 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC --Verify the Customer State Revenue table.
# MAGIC
# MAGIC SELECT * FROM gold.state_summary LIMIT 10;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the Payment Summary table.
# MAGIC
# MAGIC SELECT * FROM gold.payment_summary;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the Delivery Summary table.
# MAGIC
# MAGIC SELECT * FROM gold.delivery_summary;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the Review Summary table.
# MAGIC SELECT * FROM gold.review_summary;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Display the version history of the Gold Delta Table for auditing and tracking changes.
# MAGIC
# MAGIC DESCRIBE HISTORY gold.executive_kpi;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Layer Summary
# MAGIC
# MAGIC Business reports created:
# MAGIC
# MAGIC - Executive KPI
# MAGIC - Seller Performance
# MAGIC - Category Revenue
# MAGIC - Customer State Revenue
# MAGIC - Payment Summary
# MAGIC - Delivery Summary
# MAGIC - Review Summary
# MAGIC
# MAGIC These Gold tables are now ready for Power BI or Tableau dashboards.
# MAGIC
# MAGIC Dashboards should not use raw CSV files.
# MAGIC
# MAGIC
# MAGIC Instead, they should use the Gold Layer because it contains clean, validated, business-ready data created through the Bronze–Silver–Gold pipeline.
# MAGIC
# MAGIC This improves accuracy, performance, and reliability while preserving the raw data for auditing.

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC